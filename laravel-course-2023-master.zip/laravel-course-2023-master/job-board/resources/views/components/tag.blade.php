<div class="rounded-md border px-2 py-1">
  {{ $slot }}
</div>
